import java.util.Random;

public class DiceRoller {
    private int dieType;
    private int numberOfDice;
    private int targetNumber;
    private int bustLimit;
    private Random rand;

    public DiceRoller(int dieType, int numberOfDice, int targetNumber) 
    {
        this.dieType = dieType;
        this.numberOfDice = numberOfDice;
        this.targetNumber = targetNumber;
        this.rand = new Random();
        this.bustLimit = (int) Math.ceil(numberOfDice/2.0);
    }

    public int roll() 
    {
        int onesCount = 0;
        int result = 0;

        for (int i = 0; i < numberOfDice; i++) {
            int roll = rand.nextInt(dieType) + 1;

            if (roll == 1) {
                onesCount++;
            }

            if (roll == dieType) {
                // Open-ended roll
                int extraRoll = rand.nextInt(dieType) + 1;
                result += extraRoll;
            }

            result += roll;
        }

        if (onesCount >= bustLimit) {
            return 0;
        }

        if (result >= targetNumber) {
            return result;
        }

        return 0;
    }

    public static void main(String[] args) 
    {
        int dieType = 4;
        int numberOfDice = 10;
        int targetNumber = 25;

        DiceRoller roller = new DiceRoller(dieType, numberOfDice, targetNumber);
        int result = roller.roll();
        System.out.println("Result: " + result);
    }
}